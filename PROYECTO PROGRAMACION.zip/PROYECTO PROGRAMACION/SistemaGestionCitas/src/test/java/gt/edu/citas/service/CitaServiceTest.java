package gt.edu.citas.service;
import gt.edu.citas.dao.MemoriaDAO;import gt.edu.citas.model.*;import gt.edu.citas.exception.*;
import org.junit.jupiter.api.*;import java.time.*;import static org.junit.jupiter.api.Assertions.*;
class CitaServiceTest {
 private CitaService service;
 @BeforeEach void setup(){MemoriaDAO d=MemoriaDAO.getInstance();d.citas.clear();d.seguimientos.clear();d.pacientes.putIfAbsent("P001",new Paciente("P001","Paciente prueba","",""));d.profesionales.putIfAbsent("PR001",new Profesional("PR001","Profesional prueba","General",""));service=new CitaService();}
 private Cita cita(String id,LocalDate fecha,LocalTime hora){return new Cita(id,"P001","PR001",fecha,hora,"Consulta");}
 @Test void programaCitaCorrectamente(){Cita c=cita("T001",LocalDate.now(),LocalTime.of(10,0));service.programar(c);assertEquals(EstadoCita.PROGRAMADA,service.buscar("T001").getEstado());}
 @Test void rechazaFechaPasada(){assertThrows(FechaInvalidaException.class,()->service.programar(cita("T002",LocalDate.now().minusDays(1),LocalTime.NOON)));}
 @Test void evitaHorarioDuplicado(){service.programar(cita("T003",LocalDate.now(),LocalTime.of(11,0)));assertThrows(HorarioNoDisponibleException.class,()->service.programar(cita("T004",LocalDate.now(),LocalTime.of(11,0))));}
 @Test void cancelaCita(){service.programar(cita("T005",LocalDate.now(),LocalTime.of(12,0)));service.cancelar("T005");assertEquals(EstadoCita.CANCELADA,service.buscar("T005").getEstado());}
 @Test void impideAtenderCitaCancelada(){service.programar(cita("T006",LocalDate.now(),LocalTime.of(13,0)));service.cancelar("T006");assertThrows(EstadoCitaInvalidoException.class,()->service.atender("T006"));}
 @Test void atiendeCita(){service.programar(cita("T007",LocalDate.now(),LocalTime.of(14,0)));service.atender("T007");assertEquals(EstadoCita.ATENDIDA,service.buscar("T007").getEstado());}
 @Test void seguimientoSoloEnAtendida(){service.programar(cita("T008",LocalDate.now(),LocalTime.of(15,0)));SeguimientoService ss=new SeguimientoService();assertThrows(EstadoCitaInvalidoException.class,()->ss.registrar(new Seguimiento("ST1","T008","Nota","","")));service.atender("T008");assertDoesNotThrow(()->ss.registrar(new Seguimiento("ST2","T008","Nota","","")));}
}
