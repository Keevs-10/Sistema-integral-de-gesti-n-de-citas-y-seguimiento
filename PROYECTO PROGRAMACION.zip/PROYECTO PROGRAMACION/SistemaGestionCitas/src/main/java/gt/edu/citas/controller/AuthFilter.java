package gt.edu.citas.controller;
import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;
@WebFilter(urlPatterns={"/dashboard","/pacientes","/profesionales","/citas","/seguimiento","/historial"})
public class AuthFilter implements Filter {
 public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{
  HttpServletRequest r=(HttpServletRequest)req;HttpServletResponse s=(HttpServletResponse)res;
  if(r.getSession(false)==null||r.getSession(false).getAttribute("usuario")==null){s.sendRedirect(r.getContextPath()+"/login");return;}chain.doFilter(req,res);
 }
}
