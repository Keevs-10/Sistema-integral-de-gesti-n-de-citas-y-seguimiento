package gt.edu.citas.service;
import gt.edu.citas.dao.MemoriaDAO; import gt.edu.citas.model.Profesional; import java.util.*;
public class ProfesionalService {
 private final MemoriaDAO dao=MemoriaDAO.getInstance();
 public List<Profesional> listar(){return new ArrayList<>(dao.profesionales.values());}
 public void guardar(Profesional p){dao.profesionales.put(p.getCodigo(),p);}
}
