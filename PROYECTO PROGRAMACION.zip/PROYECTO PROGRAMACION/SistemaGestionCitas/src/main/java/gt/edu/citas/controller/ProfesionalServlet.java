package gt.edu.citas.controller;
import gt.edu.citas.model.Profesional;import gt.edu.citas.service.ProfesionalService;import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;
@WebServlet("/profesionales") public class ProfesionalServlet extends HttpServlet {
 private final ProfesionalService service=new ProfesionalService();
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{r.setAttribute("items",service.listar());r.getRequestDispatcher("/WEB-INF/views/profesionales.jsp").forward(r,s);}
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{try{service.guardar(new Profesional(r.getParameter("codigo"),r.getParameter("nombre"),r.getParameter("especialidad"),r.getParameter("disponibilidad")));s.sendRedirect(r.getContextPath()+"/profesionales");}catch(RuntimeException e){r.setAttribute("error",e.getMessage());doGet(r,s);}}
}
