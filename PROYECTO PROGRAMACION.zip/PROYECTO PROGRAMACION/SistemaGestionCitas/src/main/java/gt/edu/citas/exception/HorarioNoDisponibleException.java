package gt.edu.citas.exception;
public class HorarioNoDisponibleException extends RuntimeException { public HorarioNoDisponibleException(String m){super(m);} }
