package gt.edu.citas.model;
import java.time.LocalDateTime;
public class Seguimiento {
 private final String codigo,citaCodigo,observaciones,recomendaciones,proximaAccion;
 private final LocalDateTime fecha;
 public Seguimiento(String codigo,String citaCodigo,String observaciones,String recomendaciones,String proximaAccion){
  if(codigo==null||codigo.isBlank()||citaCodigo==null||citaCodigo.isBlank()||observaciones==null||observaciones.isBlank()) throw new IllegalArgumentException("Código, cita y observaciones son obligatorios");
  this.codigo=codigo;this.citaCodigo=citaCodigo;this.observaciones=observaciones;this.recomendaciones=recomendaciones==null?"":recomendaciones;this.proximaAccion=proximaAccion==null?"":proximaAccion;this.fecha=LocalDateTime.now();
 }
 public String getCodigo(){return codigo;} public String getCitaCodigo(){return citaCodigo;}
 public String getObservaciones(){return observaciones;} public String getRecomendaciones(){return recomendaciones;}
 public String getProximaAccion(){return proximaAccion;} public LocalDateTime getFecha(){return fecha;}
}
