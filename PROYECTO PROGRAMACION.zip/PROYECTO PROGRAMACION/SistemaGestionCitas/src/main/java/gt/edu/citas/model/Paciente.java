package gt.edu.citas.model;
public class Paciente {
 private final String codigo,nombre,telefono,correo;
 public Paciente(String codigo,String nombre,String telefono,String correo){
  if(codigo==null||codigo.isBlank()||nombre==null||nombre.isBlank()) throw new IllegalArgumentException("Código y nombre son obligatorios");
  this.codigo=codigo;this.nombre=nombre;this.telefono=telefono==null?"":telefono;this.correo=correo==null?"":correo;
 }
 public String getCodigo(){return codigo;} public String getNombre(){return nombre;}
 public String getTelefono(){return telefono;} public String getCorreo(){return correo;}
}
