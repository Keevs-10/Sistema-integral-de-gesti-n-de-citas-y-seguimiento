package gt.edu.citas.model;
public class Usuario {
 private final String correo, nombre, password; private final Rol rol;
 public Usuario(String nombre, String correo, String password, Rol rol) {
  if(nombre==null||nombre.isBlank()||correo==null||correo.isBlank()||password==null||password.isBlank()||rol==null) throw new IllegalArgumentException("Datos de usuario incompletos");
  this.nombre=nombre; this.correo=correo; this.password=password; this.rol=rol;
 }
 public String getNombre(){return nombre;} public String getCorreo(){return correo;}
 public String getPassword(){return password;} public Rol getRol(){return rol;}
}
