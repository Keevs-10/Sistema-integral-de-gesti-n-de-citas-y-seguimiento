package gt.edu.citas.controller;
import gt.edu.citas.model.Paciente;import gt.edu.citas.service.PacienteService;import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;
@WebServlet("/pacientes") public class PacienteServlet extends HttpServlet {
 private final PacienteService service=new PacienteService();
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{r.setAttribute("items",service.listar());r.getRequestDispatcher("/WEB-INF/views/pacientes.jsp").forward(r,s);}
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{try{service.guardar(new Paciente(r.getParameter("codigo"),r.getParameter("nombre"),r.getParameter("telefono"),r.getParameter("correo")));s.sendRedirect(r.getContextPath()+"/pacientes");}catch(RuntimeException e){r.setAttribute("error",e.getMessage());doGet(r,s);}}
}
