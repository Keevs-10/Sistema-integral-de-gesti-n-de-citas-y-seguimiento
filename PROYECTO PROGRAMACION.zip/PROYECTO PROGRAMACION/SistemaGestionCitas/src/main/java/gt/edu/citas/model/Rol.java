package gt.edu.citas.model;
public enum Rol { ADMINISTRADOR, PROFESIONAL, PACIENTE }
