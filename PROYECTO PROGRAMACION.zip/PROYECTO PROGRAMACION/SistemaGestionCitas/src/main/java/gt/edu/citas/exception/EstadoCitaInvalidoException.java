package gt.edu.citas.exception;
public class EstadoCitaInvalidoException extends RuntimeException { public EstadoCitaInvalidoException(String m){super(m);} }
