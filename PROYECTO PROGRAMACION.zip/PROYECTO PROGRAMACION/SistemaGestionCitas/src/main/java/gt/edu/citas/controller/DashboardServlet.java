package gt.edu.citas.controller;
import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;
@WebServlet("/dashboard") public class DashboardServlet extends HttpServlet {
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{
  r.setAttribute("pacientes",gt.edu.citas.dao.MemoriaDAO.getInstance().pacientes.size());
  r.setAttribute("profesionales",gt.edu.citas.dao.MemoriaDAO.getInstance().profesionales.size());
  r.setAttribute("citas",gt.edu.citas.dao.MemoriaDAO.getInstance().citas.size());
  r.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(r,s);
 }
}
