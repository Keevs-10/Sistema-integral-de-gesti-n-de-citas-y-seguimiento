package gt.edu.citas.controller;
import gt.edu.citas.dao.MemoriaDAO;import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;
@WebServlet("/historial") public class HistorialServlet extends HttpServlet {
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{r.setAttribute("citas",MemoriaDAO.getInstance().citas.values());r.setAttribute("seguimientos",MemoriaDAO.getInstance().seguimientos.values());r.getRequestDispatcher("/WEB-INF/views/historial.jsp").forward(r,s);}
}
