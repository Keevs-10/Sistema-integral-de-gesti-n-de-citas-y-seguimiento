package gt.edu.citas.model;
public enum EstadoCita { PROGRAMADA, CONFIRMADA, ATENDIDA, CANCELADA }
