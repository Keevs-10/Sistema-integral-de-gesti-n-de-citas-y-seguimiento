package gt.edu.citas.controller;
import gt.edu.citas.model.Seguimiento;import gt.edu.citas.service.*;import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;
@WebServlet("/seguimiento") public class SeguimientoServlet extends HttpServlet {
 private final SeguimientoService service=new SeguimientoService();private final CitaService citas=new CitaService();
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{r.setAttribute("items",service.listar());r.setAttribute("citas",citas.listar());r.getRequestDispatcher("/WEB-INF/views/seguimiento.jsp").forward(r,s);}
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{try{service.registrar(new Seguimiento(r.getParameter("codigo"),r.getParameter("cita"),r.getParameter("observaciones"),r.getParameter("recomendaciones"),r.getParameter("proximaAccion")));s.sendRedirect(r.getContextPath()+"/seguimiento");}catch(RuntimeException e){r.setAttribute("error",e.getMessage());doGet(r,s);}}
}
