package gt.edu.citas.model;
public class Profesional {
 private final String codigo,nombre,especialidad,disponibilidad;
 public Profesional(String codigo,String nombre,String especialidad,String disponibilidad){
  if(codigo==null||codigo.isBlank()||nombre==null||nombre.isBlank()||especialidad==null||especialidad.isBlank()) throw new IllegalArgumentException("Complete los datos del profesional");
  this.codigo=codigo;this.nombre=nombre;this.especialidad=especialidad;this.disponibilidad=disponibilidad==null?"Horario por definir":disponibilidad;
 }
 public String getCodigo(){return codigo;} public String getNombre(){return nombre;}
 public String getEspecialidad(){return especialidad;} public String getDisponibilidad(){return disponibilidad;}
}
