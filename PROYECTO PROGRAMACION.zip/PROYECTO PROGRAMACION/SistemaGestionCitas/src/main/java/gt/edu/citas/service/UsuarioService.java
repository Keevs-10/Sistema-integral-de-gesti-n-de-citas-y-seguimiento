package gt.edu.citas.service;
import gt.edu.citas.dao.MemoriaDAO; import gt.edu.citas.model.Usuario;
public class UsuarioService {
 public Usuario autenticar(String correo,String password){
  if(correo==null||password==null) return null;
  Usuario u=MemoriaDAO.getInstance().usuarios.get(correo.trim().toLowerCase());
  return u!=null&&u.getPassword().equals(password)?u:null;
 }
}
