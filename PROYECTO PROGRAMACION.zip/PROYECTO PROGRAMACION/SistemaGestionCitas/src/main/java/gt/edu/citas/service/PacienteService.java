package gt.edu.citas.service;
import gt.edu.citas.dao.MemoriaDAO; import gt.edu.citas.model.Paciente; import java.util.*;
public class PacienteService {
 private final MemoriaDAO dao=MemoriaDAO.getInstance();
 public List<Paciente> listar(){return new ArrayList<>(dao.pacientes.values());}
 public void guardar(Paciente p){dao.pacientes.put(p.getCodigo(),p);}
}
