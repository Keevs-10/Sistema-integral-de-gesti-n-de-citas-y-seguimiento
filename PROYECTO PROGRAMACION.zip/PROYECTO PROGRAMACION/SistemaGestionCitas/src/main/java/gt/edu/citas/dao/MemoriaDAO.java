package gt.edu.citas.dao;
import gt.edu.citas.model.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class MemoriaDAO {
 private static final MemoriaDAO INSTANCE=new MemoriaDAO();
 public static MemoriaDAO getInstance(){return INSTANCE;}
 public final Map<String,Usuario> usuarios=new ConcurrentHashMap<>();
 public final Map<String,Paciente> pacientes=new ConcurrentHashMap<>();
 public final Map<String,Profesional> profesionales=new ConcurrentHashMap<>();
 public final Map<String,Cita> citas=new ConcurrentHashMap<>();
 public final Map<String,Seguimiento> seguimientos=new ConcurrentHashMap<>();
 private MemoriaDAO(){
  usuarios.put("admin@demo.com",new Usuario("Administrador","admin@demo.com","Admin123",Rol.ADMINISTRADOR));
  usuarios.put("profesional@demo.com",new Usuario("Dra. Ana López","profesional@demo.com","Demo123",Rol.PROFESIONAL));
  usuarios.put("paciente@demo.com",new Usuario("Carlos Pérez","paciente@demo.com","Demo123",Rol.PACIENTE));
  pacientes.put("P001",new Paciente("P001","Carlos Pérez","5555-0101","paciente@demo.com"));
  profesionales.put("PR001",new Profesional("PR001","Dra. Ana López","Medicina general","Lun-Vie 08:00-16:00"));
 }
}
