package gt.edu.citas.controller;
import gt.edu.citas.model.*;import gt.edu.citas.service.*;import jakarta.servlet.*;import jakarta.servlet.http.*;import jakarta.servlet.annotation.*;import java.io.IOException;import java.time.*;
@WebServlet("/citas") public class CitaServlet extends HttpServlet {
 private final CitaService service=new CitaService();private final PacienteService ps=new PacienteService();private final ProfesionalService prs=new ProfesionalService();
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{String accion=r.getParameter("accion"),codigo=r.getParameter("codigo");try{if("confirmar".equals(accion))service.confirmar(codigo);if("cancelar".equals(accion))service.cancelar(codigo);if("atender".equals(accion))service.atender(codigo);}catch(RuntimeException e){r.setAttribute("error",e.getMessage());}
  r.setAttribute("items",service.listar());r.setAttribute("pacientes",ps.listar());r.setAttribute("profesionales",prs.listar());r.getRequestDispatcher("/WEB-INF/views/citas.jsp").forward(r,s);}
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{try{service.programar(new Cita(r.getParameter("codigo"),r.getParameter("paciente"),r.getParameter("profesional"),LocalDate.parse(r.getParameter("fecha")),LocalTime.parse(r.getParameter("hora")),r.getParameter("motivo")));s.sendRedirect(r.getContextPath()+"/citas");}catch(RuntimeException e){r.setAttribute("error",e.getMessage());doGet(r,s);}}
}
