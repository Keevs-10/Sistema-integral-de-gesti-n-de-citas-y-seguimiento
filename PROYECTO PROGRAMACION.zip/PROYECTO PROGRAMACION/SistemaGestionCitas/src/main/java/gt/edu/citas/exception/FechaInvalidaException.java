package gt.edu.citas.exception;
public class FechaInvalidaException extends RuntimeException { public FechaInvalidaException(String m){super(m);} }
