package gt.edu.citas.controller;
import gt.edu.citas.model.Usuario; import gt.edu.citas.service.UsuarioService;
import jakarta.servlet.*; import jakarta.servlet.http.*; import jakarta.servlet.annotation.*; import java.io.IOException;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
 private final UsuarioService service=new UsuarioService();
 protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{r.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(r,s);}
 protected void doPost(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{
  Usuario u=service.autenticar(r.getParameter("correo"),r.getParameter("password"));
  if(u==null){r.setAttribute("error","Correo o contraseña incorrectos");doGet(r,s);return;}
  HttpSession session=r.getSession(true);session.setAttribute("usuario",u);session.setAttribute("rol",u.getRol().name());s.sendRedirect(r.getContextPath()+"/dashboard");
 }
}
