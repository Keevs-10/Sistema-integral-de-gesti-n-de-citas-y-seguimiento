package gt.edu.citas.service;
import gt.edu.citas.dao.MemoriaDAO; import gt.edu.citas.model.*; import gt.edu.citas.exception.*;
import java.time.*; import java.util.*;
public class CitaService {
 private final MemoriaDAO dao=MemoriaDAO.getInstance();
 public synchronized void programar(Cita c){
  if(!dao.pacientes.containsKey(c.getPacienteCodigo())) throw new IllegalArgumentException("Seleccione un paciente existente");
  if(!dao.profesionales.containsKey(c.getProfesionalCodigo())) throw new IllegalArgumentException("Seleccione un profesional existente");
  if(c.getFecha().isBefore(LocalDate.now())) throw new FechaInvalidaException("No se permiten citas en fechas anteriores a hoy");
  if(dao.citas.containsKey(c.getCodigo())) throw new IllegalArgumentException("El código de cita ya existe");
  boolean ocupado=dao.citas.values().stream().anyMatch(x->x.getProfesionalCodigo().equals(c.getProfesionalCodigo())&&x.getFecha().equals(c.getFecha())&&x.getHora().equals(c.getHora())&&x.getEstado()!=EstadoCita.CANCELADA);
  if(ocupado) throw new HorarioNoDisponibleException("El profesional ya tiene una cita en esa fecha y hora");
  dao.citas.put(c.getCodigo(),c);
 }
 public List<Cita> listar(){return new ArrayList<>(dao.citas.values());}
 public Cita buscar(String codigo){Cita c=dao.citas.get(codigo);if(c==null)throw new CitaNoEncontradaException("No existe la cita "+codigo);return c;}
 public void confirmar(String codigo){Cita c=buscar(codigo);if(c.getEstado()!=EstadoCita.PROGRAMADA)throw new EstadoCitaInvalidoException("Solo se confirma una cita programada");c.setEstado(EstadoCita.CONFIRMADA);}
 public void cancelar(String codigo){Cita c=buscar(codigo);if(c.getEstado()==EstadoCita.ATENDIDA||c.getEstado()==EstadoCita.CANCELADA)throw new EstadoCitaInvalidoException("No se puede cancelar esta cita");c.setEstado(EstadoCita.CANCELADA);}
 public void atender(String codigo){Cita c=buscar(codigo);if(c.getEstado()==EstadoCita.CANCELADA)throw new EstadoCitaInvalidoException("Una cita cancelada no puede ser atendida");if(c.getEstado()!=EstadoCita.CONFIRMADA&&c.getEstado()!=EstadoCita.PROGRAMADA)throw new EstadoCitaInvalidoException("La cita ya fue atendida");c.setEstado(EstadoCita.ATENDIDA);}
}
