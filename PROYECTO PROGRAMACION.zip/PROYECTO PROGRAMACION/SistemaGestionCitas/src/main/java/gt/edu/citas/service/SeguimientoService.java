package gt.edu.citas.service;
import gt.edu.citas.dao.MemoriaDAO; import gt.edu.citas.model.*; import gt.edu.citas.exception.*; import java.util.*;
public class SeguimientoService {
 private final MemoriaDAO dao=MemoriaDAO.getInstance();
 public void registrar(Seguimiento s){Cita c=dao.citas.get(s.getCitaCodigo());if(c==null)throw new CitaNoEncontradaException("No existe la cita indicada");if(c.getEstado()!=EstadoCita.ATENDIDA)throw new EstadoCitaInvalidoException("Solo una cita atendida puede recibir seguimiento");dao.seguimientos.put(s.getCodigo(),s);}
 public List<Seguimiento> listar(){return new ArrayList<>(dao.seguimientos.values());}
}
