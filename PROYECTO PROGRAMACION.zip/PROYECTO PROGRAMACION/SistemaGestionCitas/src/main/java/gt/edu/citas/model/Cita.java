package gt.edu.citas.model;
import java.time.LocalDate;
import java.time.LocalTime;
public class Cita {
 private final String codigo,pacienteCodigo,profesionalCodigo,motivo;
 private final LocalDate fecha; private final LocalTime hora; private EstadoCita estado;
 public Cita(String codigo,String pacienteCodigo,String profesionalCodigo,LocalDate fecha,LocalTime hora,String motivo){
  if(codigo==null||codigo.isBlank()||pacienteCodigo==null||pacienteCodigo.isBlank()||profesionalCodigo==null||profesionalCodigo.isBlank()||fecha==null||hora==null||motivo==null||motivo.isBlank()) throw new IllegalArgumentException("Complete todos los datos de la cita");
  this.codigo=codigo;this.pacienteCodigo=pacienteCodigo;this.profesionalCodigo=profesionalCodigo;this.fecha=fecha;this.hora=hora;this.motivo=motivo;this.estado=EstadoCita.PROGRAMADA;
 }
 public String getCodigo(){return codigo;} public String getPacienteCodigo(){return pacienteCodigo;}
 public String getProfesionalCodigo(){return profesionalCodigo;} public LocalDate getFecha(){return fecha;}
 public LocalTime getHora(){return hora;} public String getMotivo(){return motivo;}
 public EstadoCita getEstado(){return estado;} public void setEstado(EstadoCita estado){this.estado=estado;}
}
