package gt.edu.citas.exception;
public class CitaNoEncontradaException extends RuntimeException { public CitaNoEncontradaException(String m){super(m);} }
