# Sistema Web de Gestión de Citas y Seguimiento

Proyecto académico Java Web con JSP, Servlets, MVC, POO, DAO en memoria y pruebas JUnit. **No usa una base de datos externa.** Los datos se guardan en memoria y se reinician cuando se reinicia el servidor.

## Requisitos
- JDK 17
- Apache NetBeans con soporte Maven
- Apache Tomcat 10.1 (Jakarta Servlet 6)
- Maven instalado/configurado en NetBeans

## Abrir y ejecutar
1. Descomprime `SistemaGestionCitas.zip`.
2. En NetBeans: **File > Open Project** y selecciona la carpeta que contiene `pom.xml`.
3. Configura Tomcat 10.1 en **Tools > Servers**.
4. Clic derecho en el proyecto > **Clean and Build**.
5. Ejecuta con **Run**; abre `http://localhost:8080/SistemaGestionCitas/login` si no se abre automáticamente.

## Usuarios demo
- Administrador: `admin@demo.com` / `Admin123`
- Profesional: `profesional@demo.com` / `Demo123`
- Paciente: `paciente@demo.com` / `Demo123`

Son credenciales académicas de demostración; no usar en producción.

## Módulos
Inicio de sesión con HttpSession, pacientes, profesionales, agenda, estados de citas, seguimientos, historial y panel. La aplicación aplica reglas de fecha, conflicto de horario, transiciones de estado y seguimiento solo para citas atendidas.

## Pruebas
En NetBeans, clic derecho > Test, o desde terminal `mvn test`.

## Arquitectura
Navegador (JSP/HTML/CSS) → Servlet → Service → MemoriaDAO → vista JSP.
Paquetes: `model`, `controller`, `service`, `dao`, `exception`.

## Contratos principales
- `CitaService.programar(cita)`: precondiciones: cita completa, paciente y profesional existentes, fecha no pasada; postcondición: cita almacenada en estado PROGRAMADA; invariantes: código único y sin conflicto de profesional/fecha/hora; excepciones: `FechaInvalidaException`, `HorarioNoDisponibleException`, `IllegalArgumentException`.
- `CitaService.confirmar(codigo)`: precondición: cita existente y PROGRAMADA; postcondición: CONFIRMADA; excepción: `CitaNoEncontradaException` o `EstadoCitaInvalidoException`.
- `CitaService.atender(codigo)`: precondición: cita existente y no cancelada; postcondición: ATENDIDA; excepción: `EstadoCitaInvalidoException`.
- `SeguimientoService.registrar(seguimiento)`: precondición: cita existente y ATENDIDA; postcondición: seguimiento guardado; excepción: `CitaNoEncontradaException` o `EstadoCitaInvalidoException`.

## TDA
`Cita` encapsula código, paciente, profesional, fecha, hora, motivo y estado; el estado cambia mediante operaciones del servicio. `MemoriaDAO` representa el repositorio de datos en memoria.
