# Contratos y diagramas

## Diagrama de clases (Mermaid)
```mermaid
classDiagram
 class Usuario {+String nombre +String correo +Rol rol}
 class Paciente {+String codigo +String nombre +String telefono +String correo}
 class Profesional {+String codigo +String nombre +String especialidad +String disponibilidad}
 class Cita {+String codigo +LocalDate fecha +LocalTime hora +EstadoCita estado}
 class Seguimiento {+String codigo +String observaciones +String recomendaciones +String proximaAccion}
 class CitaService {+programar(Cita) +confirmar(String) +cancelar(String) +atender(String)}
 class SeguimientoService {+registrar(Seguimiento)}
 class MemoriaDAO
 Cita --> Paciente : pacienteCodigo
 Cita --> Profesional : profesionalCodigo
 Seguimiento --> Cita : citaCodigo
 CitaService --> MemoriaDAO
 SeguimientoService --> MemoriaDAO
```

## Arquitectura
```mermaid
flowchart TD
 A[Navegador] --> B[JSP HTML CSS]
 B --> C[Servlets]
 C --> D[Servicios]
 D --> E[MemoriaDAO]
 E --> D
 D --> C
 C --> B
```

## Contratos
- **programar:** pre: cita no nula y completa, paciente/profesional existentes, fecha no pasada. post: queda almacenada como PROGRAMADA. invariante: código único y un solo espacio profesional-fecha-hora activo. excepciones: FechaInvalidaException, HorarioNoDisponibleException.
- **confirmar:** pre: cita existente y PROGRAMADA. post: estado CONFIRMADA. excepción: EstadoCitaInvalidoException.
- **atender:** pre: cita existente y no cancelada. post: estado ATENDIDA. excepción: EstadoCitaInvalidoException.
- **registrar seguimiento:** pre: cita existente y ATENDIDA, observaciones completas. post: seguimiento almacenado. excepción: CitaNoEncontradaException, EstadoCitaInvalidoException.
